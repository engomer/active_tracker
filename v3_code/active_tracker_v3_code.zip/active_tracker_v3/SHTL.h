void initSHT();
void updateSHT();
float updateSHT_Temp();
float updateSHT_Hum();
float getTemp();
float getHum();
