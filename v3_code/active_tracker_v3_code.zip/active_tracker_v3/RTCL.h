void setRTC(String dateTime);

String getDate();
String getTime();

String getDay();
String getMonth();
String getYear();

String getHour();
String getMinute();
String getSecond();
